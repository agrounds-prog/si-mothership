(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports) module.exports=api;
  if(root) root.SI_CalcEngine=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';

  class CalcError extends Error{
    constructor(code,message,start,end){super(message);this.name='CalcError';this.code=code;this.start=start;this.end=end;}
  }

  function bgcd(a,b){a=a<0n?-a:a;b=b<0n?-b:b;while(b){const t=a%b;a=b;b=t;}return a||1n;}
  class Rational{
    constructor(n,d=1n){
      n=BigInt(n);d=BigInt(d);
      if(d===0n) throw new CalcError('DIVIDE_BY_ZERO','Cannot divide by zero.');
      if(d<0n){n=-n;d=-d;}
      const g=bgcd(n,d);this.n=n/g;this.d=d/g;
    }
    add(o){o=asRational(o);return new Rational(this.n*o.d+o.n*this.d,this.d*o.d);}
    sub(o){o=asRational(o);return new Rational(this.n*o.d-o.n*this.d,this.d*o.d);}
    mul(o){o=asRational(o);return new Rational(this.n*o.n,this.d*o.d);}
    div(o){o=asRational(o);if(o.n===0n)throw new CalcError('DIVIDE_BY_ZERO','Cannot divide by zero.');return new Rational(this.n*o.d,this.d*o.n);}
    neg(){return new Rational(-this.n,this.d);}
    powInt(k){
      k=BigInt(k);
      if(k===0n)return new Rational(1n);
      if(k<0n){if(this.n===0n)throw new CalcError('DIVIDE_BY_ZERO','Zero cannot be raised to a negative power.');return new Rational(this.d,this.n).powInt(-k);}
      return new Rational(this.n**k,this.d**k);
    }
    toNumber(){return Number(this.n)/Number(this.d);}
    toString(){return this.d===1n?String(this.n):`${this.n}/${this.d}`;}
    static fromLiteral(raw){
      const s=String(raw);
      if(/[eE]/.test(s)) return null;
      if(!s.includes('.')) return new Rational(BigInt(s));
      const neg=s.startsWith('-');
      const body=neg?s.slice(1):s;
      const [a,b='']=body.split('.');
      const den=10n**BigInt(b.length);
      const num=BigInt((a||'0')+(b||''))*(neg?-1n:1n);
      return new Rational(num,den);
    }
  }
  function asRational(v){if(v instanceof Rational)return v;throw new CalcError('INVALID_ARGUMENT','Expected an exact rational value.');}
  function isR(v){return v instanceof Rational;}
  function toNum(v){return isR(v)?v.toNumber():Number(v);}
  function finite(n){if(!Number.isFinite(n))throw new CalcError('OVERFLOW','Result is outside the supported numeric range.');return n;}
  function nearInt(n){const r=Math.round(n);return Math.abs(n-r)<1e-12?r:n;}

  const FN=new Set(['sin','cos','tan','asin','acos','atan','sqrt','root','log','ln','pow10','exp','abs','ncr','npr','fact']);
  const CONSTS=new Set(['pi','e']);
  function normalizeSource(src){return String(src||'').replace(/[×·]/g,'*').replace(/÷/g,'/').replace(/[−–—]/g,'-').replace(/π/g,'pi').replace(/√/g,'sqrt').replace(/²/g,'^2');}

  function tokenize(source){
    const s=normalizeSource(source);const out=[];let i=0;
    while(i<s.length){
      const c=s[i];
      if(/\s/.test(c)){i++;continue;}
      if(/[0-9.]/.test(c)){
        const start=i;let dots=0;
        while(i<s.length&&/[0-9.]/.test(s[i])){if(s[i]==='.')dots++;i++;}
        if(dots>1)throw new CalcError('SYNTAX','Malformed number.',start,i);
        if((s[i]==='e'||s[i]==='E')&&/[+\-0-9]/.test(s[i+1]||'')){
          i++;if(/[+\-]/.test(s[i]))i++;
          const eStart=i;while(i<s.length&&/[0-9]/.test(s[i]))i++;
          if(i===eStart)throw new CalcError('SYNTAX','Malformed scientific notation.',start,i);
        }
        const raw=s.slice(start,i);if(raw==='.')throw new CalcError('SYNTAX','A decimal point needs a number.',start,i);
        out.push({type:'number',value:raw,start,end:i});continue;
      }
      if(/[A-Za-z_]/.test(c)){
        const start=i;i++;while(i<s.length&&/[A-Za-z0-9_]/.test(s[i]))i++;
        out.push({type:'ident',value:s.slice(start,i).toLowerCase(),start,end:i});continue;
      }
      const single={'(':'lparen',')':'rparen',',':'comma','+':'op','-':'op','*':'op','/':'op','^':'op','!':'op','%':'op'}[c];
      if(single){out.push({type:single,value:c,start:i,end:i+1});i++;continue;}
      throw new CalcError('SYNTAX',`Unsupported character “${c}”.`,i,i+1);
    }
    const expanded=[];
    const endsValue=t=>t&&(t.type==='number'||t.type==='rparen'||(t.type==='ident'&&!FN.has(t.value))||(t.type==='op'&&(t.value==='!'||t.value==='%')));
    const startsValue=t=>t&&(t.type==='number'||t.type==='ident'||t.type==='lparen');
    for(let j=0;j<out.length;j++){
      const prev=expanded[expanded.length-1],next=out[j];
      const functionCall=prev&&prev.type==='ident'&&FN.has(prev.value)&&next.type==='lparen';
      if(endsValue(prev)&&startsValue(next)&&!functionCall)expanded.push({type:'op',value:'*',start:next.start,end:next.start,implicit:true});
      expanded.push(next);
    }
    expanded.push({type:'eof',value:'',start:s.length,end:s.length});return expanded;
  }

  class Parser{
    constructor(tokens){this.t=tokens;this.i=0;}
    peek(){return this.t[this.i];}
    take(type,value){const t=this.peek();if(t.type===type&&(value===undefined||t.value===value)){this.i++;return t;}return null;}
    need(type,value,msg){const t=this.take(type,value);if(!t){const p=this.peek();throw new CalcError('SYNTAX',msg||`Expected ${value||type}.`,p.start,p.end);}return t;}
    parse(){const node=this.add();const p=this.peek();if(p.type!=='eof')throw new CalcError('SYNTAX','Unexpected input.',p.start,p.end);return node;}
    add(){let n=this.mul();for(;;){if(this.take('op','+'))n={k:'bin',op:'+',a:n,b:this.mul()};else if(this.take('op','-'))n={k:'bin',op:'-',a:n,b:this.mul()};else break;}return n;}
    mul(){let n=this.unary();for(;;){if(this.take('op','*'))n={k:'bin',op:'*',a:n,b:this.unary()};else if(this.take('op','/'))n={k:'bin',op:'/',a:n,b:this.unary()};else break;}return n;}
    unary(){if(this.take('op','+'))return {k:'un',op:'+',a:this.unary()};if(this.take('op','-'))return {k:'un',op:'-',a:this.unary()};return this.power();}
    power(){let n=this.postfix();if(this.take('op','^'))n={k:'bin',op:'^',a:n,b:this.unary()};return n;}
    postfix(){let n=this.primary();for(;;){if(this.take('op','!'))n={k:'post',op:'!',a:n};else if(this.take('op','%'))n={k:'post',op:'%',a:n};else break;}return n;}
    primary(){
      const num=this.take('number');if(num)return {k:'num',raw:num.value};
      const id=this.take('ident');
      if(id){
        if(this.take('lparen')){const args=[];if(!this.take('rparen')){do{args.push(this.add());}while(this.take('comma'));this.need('rparen',undefined,'Missing closing parenthesis.');}return {k:'call',name:id.value,args};}
        return {k:'name',name:id.value};
      }
      if(this.take('lparen')){const n=this.add();this.need('rparen',undefined,'Missing closing parenthesis.');return n;}
      const p=this.peek();throw new CalcError('SYNTAX','Expected a number, constant, function, or parenthesis.',p.start,p.end);
    }
  }

  function literal(raw){const r=Rational.fromLiteral(raw);return r||finite(Number(raw));}
  function bin(op,a,b){
    if(op==='+'||op==='-'||op==='*'||op==='/'){
      if(isR(a)&&isR(b)){if(op==='+')return a.add(b);if(op==='-')return a.sub(b);if(op==='*')return a.mul(b);return a.div(b);}
      const x=toNum(a),y=toNum(b);if(op==='/'&&y===0)throw new CalcError('DIVIDE_BY_ZERO','Cannot divide by zero.');
      return finite(op==='+'?x+y:op==='-'?x-y:op==='*'?x*y:x/y);
    }
    if(op==='^'){
      const y=toNum(b);
      if(isR(a)&&Number.isInteger(y)&&Math.abs(y)<=10000)return a.powInt(BigInt(y));
      const x=toNum(a);if(x<0&&!Number.isInteger(y))throw new CalcError('DOMAIN','This power is not real-valued.');return finite(Math.pow(x,y));
    }
    throw new CalcError('UNDEFINED','Unknown operator.');
  }
  function factorial(v){const n=toNum(v);if(!Number.isInteger(n)||n<0)throw new CalcError('DOMAIN','Factorial requires a nonnegative integer.');if(n>170)throw new CalcError('OVERFLOW','Factorial is too large.');let r=1;for(let i=2;i<=n;i++)r*=i;return Number.isSafeInteger(r)?new Rational(BigInt(r)):finite(r);}
  function intArg(v,label){const n=toNum(v);if(!Number.isInteger(n)||n<0)throw new CalcError('DOMAIN',`${label} requires nonnegative integers.`);return n;}
  function npr(n,r){n=intArg(n,'nPr');r=intArg(r,'nPr');if(r>n)throw new CalcError('DOMAIN','nPr requires r ≤ n.');let v=1;for(let k=0;k<r;k++)v*=n-k;return Number.isSafeInteger(v)?new Rational(BigInt(v)):finite(v);}
  function ncr(n,r){n=intArg(n,'nCr');r=intArg(r,'nCr');if(r>n)throw new CalcError('DOMAIN','nCr requires r ≤ n.');r=Math.min(r,n-r);let v=1;for(let k=1;k<=r;k++)v=v*(n-r+k)/k;return Number.isSafeInteger(v)?new Rational(BigInt(Math.round(v))):finite(v);}
  function toRad(x,mode){return mode==='rad'?x:x*Math.PI/180;}
  function fromRad(x,mode){return mode==='rad'?x:x*180/Math.PI;}
  function call(name,args,ctx){
    const nums=args.map(toNum),one=()=>{if(args.length!==1)throw new CalcError('INVALID_ARGUMENT',`${name} expects one value.`);return nums[0];};
    switch(name){
      case 'sin':return finite(nearInt(Math.sin(toRad(one(),ctx.angleMode))));
      case 'cos':return finite(nearInt(Math.cos(toRad(one(),ctx.angleMode))));
      case 'tan':return finite(nearInt(Math.tan(toRad(one(),ctx.angleMode))));
      case 'asin':{const x=one();if(x<-1||x>1)throw new CalcError('DOMAIN','Inverse sine requires a value from -1 to 1.');return finite(fromRad(Math.asin(x),ctx.angleMode));}
      case 'acos':{const x=one();if(x<-1||x>1)throw new CalcError('DOMAIN','Inverse cosine requires a value from -1 to 1.');return finite(fromRad(Math.acos(x),ctx.angleMode));}
      case 'atan':return finite(fromRad(Math.atan(one()),ctx.angleMode));
      case 'sqrt':{const x=one();if(x<0)throw new CalcError('DOMAIN','Square root requires a nonnegative real number.');if(isR(args[0])){const rn=args[0];const sn=BigInt(Math.trunc(Math.sqrt(Number(rn.n<0n?-rn.n:rn.n))));const sd=BigInt(Math.trunc(Math.sqrt(Number(rn.d))));if(sn*sn===rn.n&&sd*sd===rn.d)return new Rational(sn,sd);}return finite(Math.sqrt(x));}
      case 'root':{if(args.length!==2)throw new CalcError('INVALID_ARGUMENT','root expects degree and value.');const degree=nums[0],x=nums[1];if(degree===0)throw new CalcError('DOMAIN','Root degree cannot be zero.');if(x<0&&Math.abs(degree%2)!==1)throw new CalcError('DOMAIN','This root is not real-valued.');return finite(x<0?-Math.pow(-x,1/degree):Math.pow(x,1/degree));}
      case 'log':{const x=one();if(x<=0)throw new CalcError('DOMAIN','log requires a positive value.');return finite(Math.log10(x));}
      case 'ln':{const x=one();if(x<=0)throw new CalcError('DOMAIN','ln requires a positive value.');return finite(Math.log(x));}
      case 'pow10':return finite(Math.pow(10,one()));
      case 'exp':return finite(Math.exp(one()));
      case 'abs':{if(args.length!==1)throw new CalcError('INVALID_ARGUMENT','abs expects one value.');return isR(args[0])?new Rational(args[0].n<0n?-args[0].n:args[0].n,args[0].d):Math.abs(nums[0]);}
      case 'fact':return factorial(args.length===1?args[0]:(()=>{throw new CalcError('INVALID_ARGUMENT','fact expects one value.');})());
      case 'ncr':if(args.length!==2)throw new CalcError('INVALID_ARGUMENT','nCr expects two values.');return ncr(args[0],args[1]);
      case 'npr':if(args.length!==2)throw new CalcError('INVALID_ARGUMENT','nPr expects two values.');return npr(args[0],args[1]);
      default:throw new CalcError('UNDEFINED',`Unknown function “${name}”.`);
    }
  }
  function evaluateNode(n,ctx){
    switch(n.k){
      case 'num':return literal(n.raw);
      case 'name':{
        if(n.name==='pi')return Math.PI;if(n.name==='e')return Math.E;if(n.name==='ans'){if(ctx.ans==null)throw new CalcError('UNDEFINED','Ans is not available yet.');return ctx.ans;}
        if(Object.prototype.hasOwnProperty.call(ctx.memory,n.name))return ctx.memory[n.name];
        throw new CalcError('UNDEFINED',`Variable “${n.name}” has no stored value.`);
      }
      case 'un':{const a=evaluateNode(n.a,ctx);return n.op==='-'?(isR(a)?a.neg():-toNum(a)):a;}
      case 'bin':return bin(n.op,evaluateNode(n.a,ctx),evaluateNode(n.b,ctx));
      case 'post':{const a=evaluateNode(n.a,ctx);if(n.op==='!')return factorial(a);if(n.op==='%')return isR(a)?a.div(new Rational(100n)):toNum(a)/100;break;}
      case 'call':return call(n.name,n.args.map(x=>evaluateNode(x,ctx)),ctx);
    }
    throw new CalcError('UNDEFINED','Unable to evaluate expression.');
  }

  function cleanExp(s){return s.replace(/\.0+e/,'e').replace(/(\.\d*?[1-9])0+e/,'$1e').replace('e+','e');}
  function formatNumber(n,fmt){
    n=nearInt(Number(n));if(Object.is(n,-0))n=0;
    if(!Number.isFinite(n))return 'Error';
    if(fmt==='scientific')return cleanExp(n.toExponential(9));
    const a=Math.abs(n);if((a!==0&&a<1e-9)||a>=1e11)return cleanExp(n.toExponential(9));
    return Number(n.toPrecision(12)).toString();
  }
  function formatValue(v,opt={}){
    const exact=opt.exactMode!==false,fmt=opt.numberFormat||'normal';
    if(isR(v)&&exact)return v.toString();
    return formatNumber(toNum(v),fmt);
  }
  function serialize(v){return isR(v)?{kind:'rational',numerator:String(v.n),denominator:String(v.d)}:{kind:'number',value:Number(v)};}
  function deserialize(v){if(v==null)return null;if(v instanceof Rational||typeof v==='number')return v;if(v.kind==='rational')return new Rational(BigInt(v.numerator),BigInt(v.denominator));if(v.kind==='number')return Number(v.value);return null;}
  function normalizeMemory(memory){const out={};for(const [k,v] of Object.entries(memory||{})){const d=deserialize(v);if(d!=null)out[String(k).toLowerCase()]=d;}return out;}
  function evaluate(source,opt={}){
    try{
      const tokens=tokenize(source);const ast=new Parser(tokens).parse();
      const ctx={angleMode:opt.angleMode==='rad'?'rad':'deg',memory:normalizeMemory(opt.memory),ans:deserialize(opt.ans)};
      const value=evaluateNode(ast,ctx);
      return {ok:true,value,serialized:serialize(value),display:formatValue(value,opt),decimalDisplay:formatValue(value,{...opt,exactMode:false})};
    }catch(err){const e=err instanceof CalcError?err:new CalcError('UNDEFINED','Unable to evaluate expression.');return {ok:false,error:{code:e.code,message:e.message,start:e.start,end:e.end}};}
  }
  return {CalcError,Rational,tokenize,evaluate,formatValue,serialize,deserialize,normalizeSource};
});
